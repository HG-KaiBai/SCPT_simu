# Installation

[Back to README](../README.md)

## Requirements

SurvPT is a source R package containing C++17 code. It requires `Rcpp` (at least 1.1.0), `RcppArmadillo`, and a working compiler toolchain. R's standard `stats` package supplies simulation and optimization functions. A local validation used R 4.5.1, Windows x64, and Rtools45; other platform and version combinations have not been validated in this repository.

- **Windows:** install the [Rtools release appropriate for your R version](https://cran.r-project.org/bin/windows/Rtools/).
- **macOS:** install the compiler tools required by your R distribution; consult [R for macOS tools](https://mac.r-project.org/tools/).
- **Linux:** install R development headers, `make`, and a C++17 compiler through your distribution. BLAS, LAPACK, and the Fortran runtime must be available to R's linker.

The package uses R's BLAS/LAPACK and OpenMP make variables. Its current makefiles also add debug compilation flags. Compiler performance and compatibility can therefore differ across platforms; see [package-check notes](limitations.md#package-check-notes).

## Install from GitHub

Install the package directly from the repository:

```r
install.packages(c("remotes", "Rcpp", "RcppArmadillo"))
remotes::install_github("HG-KaiBai/SurvPT", upgrade = "never")
library(SurvPT)
```

For reproducibility, pass an existing commit SHA with `ref = "YOUR_COMMIT_SHA"`. SurvPT is distributed under the [MIT license](../LICENSE.md).

## Install a local source archive

If you have a source archive such as `SurvPT_0.4.2.tar.gz`, set the R working directory to its location or supply an absolute path:

```r
install.packages(c("Rcpp", "RcppArmadillo"))
install.packages("SurvPT_0.4.2.tar.gz", repos = NULL, type = "source")
library(SurvPT)
packageVersion("SurvPT")
```

`repos = NULL` does not fetch missing dependencies for this local archive, so install those first. Restart R before replacing a loaded package, particularly on Windows where a loaded DLL can be locked.

## Install the Windows binary

The `SurvPT_0.4.2.zip` binary is built with R 4.5.1 for Windows x64. With R 4.5.x,
set the working directory to the archive's location and install it directly:

```r
install.packages("Rcpp")
install.packages("SurvPT_0.4.2.zip", repos = NULL, type = "win.binary")
library(SurvPT)
packageVersion("SurvPT")
```

This binary installation does not require local compilation. Use the source
archive and the appropriate compiler toolchain for other platforms.

## Install from a checkout

Clone the repository, then install from its root directory:

```sh
git clone https://github.com/HG-KaiBai/SurvPT.git
cd SurvPT
R CMD INSTALL --preclean .
```

Run the dependency-installation command above first. A GitHub ZIP download is a checkout snapshot, not an R source-package archive: extract it and run `R CMD INSTALL` on the directory containing `DESCRIPTION`.

## Confirm the installation

```r
library(SurvPT)
packageVersion("SurvPT")
find.package("SurvPT")
help(package = "SurvPT")
citation("SurvPT")
```

Run [the quickstart](../Examples/quickstart.R) from a checkout using `Rscript Examples/quickstart.R`. It needs only the installed package and standard R packages and prints a compact validation summary.

## Reproducibility

Version 0.4.2 uses reference-count pruning, asymmetric tail-path Beta priors,
centering-based initialization followed by a single MAP-EM fit, and optional
DA-Gibbs. `flat=TRUE` selects Beta(1,1) for the entire fit and sampler. All families
leave the tail shape unspecified. Survival and density predictions beyond
the largest finite endpoint, including `Inf`, are `NA`. Curves and summaries,
including a separate summary of `S(Tau)`, are returned by `predict()`.
`survPT()` accepts only fitting parameters; use
`predict(fit,times,0.95)` to sample and predict at target times. Refit earlier analyses when adopting these changes;
see [Methods](methods.md) and [NEWS](../NEWS.md).

Version 0.2.0 changes censored-data allocations for exponential and Weibull PT bases and for the uniform infinite terminal interval. Refit analyses made with 0.1.0 instead of assuming identical estimates. Record `packageVersion("SurvPT")`, `sessionInfo()`, the chosen support, base parameters, stopping controls, and source commit or archive checksum.
